
# Scheme Capital - MPesa Backend (Render)

Deploy this Express server to Render to handle Safaricom Daraja (MPesa) STK Push requests.

## Steps

1. Copy `.env.example` to `.env` and fill the environment variables:
   - `MPESA_CONSUMER_KEY`, `MPESA_CONSUMER_SECRET`
   - `MPESA_SHORTCODE` (use 174379 for sandbox)
   - `MPESA_PASSKEY`
   - `CALLBACK_BASE_URL` (Render will give you a URL after deploy)
   - `ENVIRONMENT` (sandbox or production)

2. Push to Git and connect to Render, or upload the project directly.

3. On Render, create a Web Service, set env vars in the dashboard, and deploy.

4. Test the endpoint:
   POST /api/mpesa/initiate with JSON body:
   {
     "phone": "2547XXXXXXXX",
     "amount": 100
   }

5. Monitor logs for the callback (Daraja will call /api/mpesa/callback).

## Notes
- The callback currently logs the payload. You must parse it, verify, and update your database (Firestore) with transaction status and user balance.
- Never expose consumer secrets in frontend code.
