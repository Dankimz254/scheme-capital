const axios = require('axios');

module.exports = {
  getAccessToken: async (consumerKey, consumerSecret, base) => {
    const token = Buffer.from(`${consumerKey}:${consumerSecret}`).toString('base64');
    const url = `${base}/oauth/v1/generate?grant_type=client_credentials`;
    const resp = await axios.get(url, { headers: { Authorization: `Basic ${token}` } });
    return resp.data.access_token;
  }
};