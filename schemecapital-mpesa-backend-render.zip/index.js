/**
 * Scheme Capital - MPesa Backend (Render-ready)
 */
const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
require('dotenv').config();

const app = express();
app.use(bodyParser.json());

const {
  MPESA_CONSUMER_KEY,
  MPESA_CONSUMER_SECRET,
  MPESA_SHORTCODE,
  MPESA_PASSKEY,
  CALLBACK_BASE_URL,
  ENVIRONMENT
} = process.env;

const DARJA_BASE = (ENVIRONMENT === 'production')
  ? 'https://api.safaricom.co.ke'
  : 'https://sandbox.safaricom.co.ke';

async function getAccessToken() {
  const token = Buffer.from(`${MPESA_CONSUMER_KEY}:${MPESA_CONSUMER_SECRET}`).toString('base64');
  const url = `${DARJA_BASE}/oauth/v1/generate?grant_type=client_credentials`;
  const resp = await axios.get(url, { headers: { Authorization: `Basic ${token}` } });
  return resp.data.access_token;
}

function getTimestamp() {
  const d = new Date();
  const yyyy = d.getFullYear().toString();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  const hh = String(d.getHours()).padStart(2, '0');
  const min = String(d.getMinutes()).padStart(2, '0');
  const ss = String(d.getSeconds()).padStart(2, '0');
  return `${yyyy}${mm}${dd}${hh}${min}${ss}`;
}

app.get('/', (req, res) => {
  res.send({ ok: true, message: 'Scheme Capital MPesa backend running' });
});

app.post('/api/mpesa/initiate', async (req, res) => {
  try {
    const { phone, amount, accountReference = 'SchemeCapital', transactionDesc = 'Deposit to Scheme Capital' } = req.body;
    if (!phone || !amount) return res.status(400).json({ error: 'phone and amount required' });

    const accessToken = await getAccessToken();
    const timestamp = getTimestamp();
    const password = Buffer.from(`${MPESA_SHORTCODE}${MPESA_PASSKEY}${timestamp}`).toString('base64');

    const payload = {
      BusinessShortCode: MPESA_SHORTCODE,
      Password: password,
      Timestamp: timestamp,
      TransactionType: "CustomerPayBillOnline",
      Amount: amount,
      PartyA: phone,
      PartyB: MPESA_SHORTCODE,
      PhoneNumber: phone,
      CallBackURL: `${CALLBACK_BASE_URL}/api/mpesa/callback`,
      AccountReference: accountReference,
      TransactionDesc: transactionDesc
    };

    const url = `${DARJA_BASE}/mpesa/stkpush/v1/processrequest`;
    const mpesaResp = await axios.post(url, payload, { headers: { Authorization: `Bearer ${accessToken}` } });
    return res.json({ ok: true, daraja: mpesaResp.data });
  } catch (err) {
    console.error('initiate error', err?.response?.data || err.message || err);
    return res.status(500).json({ error: 'failed to initiate', details: err?.response?.data || err.message });
  }
});

app.post('/api/mpesa/callback', async (req, res) => {
  try {
    const payload = req.body;
    console.log('MPESA CALLBACK RECEIVED:', JSON.stringify(payload, null, 2));
    res.status(200).send({ ResultCode: 0, ResultDesc: 'Accepted' });
  } catch (err) {
    console.error('callback error', err);
    res.status(500).send({ error: 'callback handling failed' });
  }
});

app.post('/api/mpesa/withdraw', async (req, res) => {
  return res.json({ ok: true, message: 'withdraw endpoint placeholder - implement B2C or paybill payout as required' });
});

const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`Server listening on ${port}`));